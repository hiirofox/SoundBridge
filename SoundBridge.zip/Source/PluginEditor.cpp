/*
  ==============================================================================

	This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
LModelAudioProcessorEditor::LModelAudioProcessorEditor(LModelAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
	// Make sure that before the constructor has finished, you've set the
	// editor's size to whatever you need it to be.
	//setWantsKeyboardFocus(true);

	setResizable(true, true); // �������ڵ�����С

	setOpaque(false);  // �����ڱ߿��������

	//setResizeLimits(64 * 11, 64 * 5, 10000, 10000); // ������С����Ϊ300x200��������Ϊ800x600
	setSize(64 * 9, 64 * 3);
	setResizeLimits(64 * 9, 64 * 3, 64 * 13, 64 * 3);

	//constrainer.setFixedAspectRatio(11.0 / 4.0);  // ����Ϊ16:9����
	//setConstrainer(&constrainer);  // �󶨴��ڵĿ�������

	/*
	K_Corr.setText("corr");
	K_Corr.ParamLink(audioProcessor.GetParams(), "corr");
	addAndMakeVisible(K_Corr);
	K_Formant.setText("formant");
	K_Formant.ParamLink(audioProcessor.GetParams(), "formant");
	addAndMakeVisible(K_Formant);
	K_Glide.setText("glide");
	K_Glide.ParamLink(audioProcessor.GetParams(), "glide");
	addAndMakeVisible(K_Glide);
	K_Mix.setText("mix");
	K_Mix.ParamLink(audioProcessor.GetParams(), "mix");
	addAndMakeVisible(K_Mix);
	K_Randpan.setText("randpan");
	K_Randpan.ParamLink(audioProcessor.GetParams(), "randpan");
	addAndMakeVisible(K_Randpan);
	K_Keep.setText("keepForm");
	K_Keep.ParamLink(audioProcessor.GetParams(), "keep");
	addAndMakeVisible(K_Keep);
	*/
	snd.SetAudioFileReader(&p.audioReader);
	snd.SetSoundDB(&p.sdbl);
	snd.SetUpdataSignal(&p.audioname, &p.updataFlag);
	addAndMakeVisible(snd);
	startTimerHz(30);
}

LModelAudioProcessorEditor::~LModelAudioProcessorEditor()
{
}

//==============================================================================
void LModelAudioProcessorEditor::paint(juce::Graphics& g)
{
	g.fillAll(juce::Colour(0x00, 0x00, 0x00));

	g.fillAll();
	g.setFont(juce::Font("FIXEDSYS", 16.0, 1));
	g.setColour(juce::Colour(0xff00ff00));;

	int w = getBounds().getWidth(), h = getBounds().getHeight();

	g.drawText("L-MODEL SoundBridge", juce::Rectangle<float>(32, 16, w, 16), 1);
}

void LModelAudioProcessorEditor::resized()
{
	juce::Rectangle<int> bound = getBounds();
	int x = bound.getX(), y = bound.getY(), w = bound.getWidth(), h = bound.getHeight();
	auto convXY = juce::Rectangle<int>::leftTopRightBottom;

	/*K_Corr.setBounds(w - 32 - 64 * 3, 32 + 64 * 0, 64, 64);
	K_Formant.setBounds(w - 32 - 64 * 2, 32 + 64 * 0, 64, 64);
	K_Keep.setBounds(w - 32 - 64 * 1, 32 + 64 * 0, 64, 64);
	K_Randpan.setBounds(w - 32 - 64 * 3, 32 + 64 * 1, 64, 64);
	K_Glide.setBounds(w - 32 - 64 * 2, 32 + 64 * 1, 64, 64);
	K_Mix.setBounds(w - 32 - 64 * 1, 32 + 64 * 1, 64, 64);
	*/
	snd.setBounds(32, 32, w - 64, h - 64);

}

void LModelAudioProcessorEditor::timerCallback()
{
	repaint();
}
