#pragma once

#ifndef _MY_COMPLEX_
#define _MY_COMPLEX_

#include <math.h>

void fft_f32(float* are, float* aim, int n, int inv);


#endif